package postgres

import (
	"testing"

	"github.com/volts-dev/orm"
)

func TestAnd(t *testing.T) {
	orm.TestAnd("", t)
}
