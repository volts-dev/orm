package postgres

import (
	"testing"

	"github.com/volts-dev/orm"
)

func TestOr(t *testing.T) {
	orm.TestOr("", t)
}
