package postgres

import (
	"testing"

	"github.com/volts-dev/orm"
)

func TestIn(t *testing.T) {
	orm.TestIn("", t)
}
