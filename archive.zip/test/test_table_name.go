package test

import (
	"testing"
)

func custom_table_name(title string, t *testing.T) {
	//	lUserMdl := orm.GetModel("res.user")
}
